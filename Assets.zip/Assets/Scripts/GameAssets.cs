﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameAssets : MonoBehaviour
{
    // Declare reference to GameAssets class
    private static GameAssets instance;

    public static GameAssets GetInstance()
    {
        return instance;
    }

    // Awake is called as soon as a script becomes active
    void Awake()
    {
        instance = this;
    }

    // Create our public sprites
    //public Sprite pipeHeadSprite;

    // Pipehead and Pipebody prefab references
    public Transform pipeHead;
    public Transform pipeBody;

}

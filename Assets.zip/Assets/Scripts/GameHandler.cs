﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using CodeMonkey;
using CodeMonkey.Utils;

public class GameHandler : MonoBehaviour {
    // Start is called before the first frame update
    void Start() {
        // Output to the console window a message
        Debug.Log("Hello World");

        // Output the pipe head sprite to the screen
        //GameObject gameObject = new GameObject("Pipe", typeof(SpriteRenderer));
        //gameObject.GetComponent<SpriteRenderer>().sprite = GameAssets.GetInstance().pipeHeadSprite;

    }   

}


 /*
        // Create a  integer variable
        int count = 0;
        FunctionPeriodic.Create(() =>
        {
            CMDebug.TextPopupMouse("Ding! " + count);
            count++;
        }, .300f);
*/